import { Productlist, UserDetailForPayment } from "../model/api.model";

export  class Constant {  
    public static userdetailforpayment?: UserDetailForPayment;
    public static optionArr = new Array('196','202','204','213','178','187','114','185','165','183','199','117','163','168','152','181','161','153');
    //test Url
    // public static paysuccess = 'http://localhost/apiemotiongIft/success.php';   
    //prod Url
    public static paysuccess = ' http://dev.vedanttechnosys.com/angular/emotiongift/apiemotiongIft/success.php';   
        
}  