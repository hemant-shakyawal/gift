export class UrlConstants {
    // Test url
    // public static BASE_URL = 'https://www.emotiongift.com/';
    // public static BASE_URL = 'http://185.105.34.152/apiemotiongIft';

    // test server
    // public static BASE_URL = 'http://localhost/apiemotiongIft';    
    // prod server  
   public static BASE_URL = 'http://dev.vedanttechnosys.com/angular/emotiongift/apiemotiongIft';  

    public static API_BASE_URL = UrlConstants.BASE_URL + '/api.php?rquest=';
    public static getCategoryDetail = UrlConstants.API_BASE_URL + 'getCategory';
    public static CategoryDetail = UrlConstants.API_BASE_URL + 'getCategoryById';
    public static ProductDetail = UrlConstants.API_BASE_URL + 'getProductDetailById';
    public static GenerateHash = UrlConstants.API_BASE_URL + 'generateHash';
    public static SearchDetail = UrlConstants.API_BASE_URL + 'serarchProduct';

    // for node server
    // public static BASE_URL = 'http://localhost:9095/';
    // public static API_BASE_URL = UrlConstants.BASE_URL + 'api/';
    // public static getCategoryDetail = UrlConstants.API_BASE_URL + 'getCategoryDetail';
}