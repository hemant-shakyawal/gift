export class GetCategoryDetail {
    constructor(
        public message?,
​        public status?,
        public statusCode?,
        public data? : CategoryList[],
    ) { }
}

export class GetProductDetail {
    constructor(
        public message?,
​        public status?,
        public statusCode?,
        public data? : Productlist[],
    ) { }
}



export class CategoryList {
    constructor(
        public category_id?,
        public parent_id?,
        public name?,
        public url?,
        public description?,
        public language_id?,
        public productDetail?: Productlist[],
    ) { }
}

export class Productlist {
    constructor(
        public product_id?,
        public image?,
        public price?,
        public category_id?,
        public name?,
        public description?,
        public meta_description?,
        public meta_keyword?,
        public proQuantity?,
        public proWight?,
        public proQuality?,
        public proMessage?,
    ) { }
}

export class GenerateHash {
    constructor(
        public message?,
    ​    public status?,
        public statusCode?,
        public data?,
    ) { }
}

export class UserDetailForPayment {
    constructor(
        public socialId?,
        public s_name?,
    ​    public s_email?,
        public s_mobile?,
        public s_address?,
        public s_pin?,
        public r_name?,
    ​    public r_email?,
        public r_mobile?,
        public r_address?,
        public r_pin?,
        public totalAmount?,
        public productDetail?: Productlist[]
    ) { }
}