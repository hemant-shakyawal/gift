import { Injectable } from '@angular/core';
import { Observable, Subject } from 'rxjs';

@Injectable()
export class NotificationService {
    public subject = new Subject<any>();
    public searchString = new Subject<any>();

    sendMessage(message: any) {
        this.subject.next(message);
    }

    clearMessage() {
        this.subject.next();
    }

    getMessage(): Observable<any> {
        return this.subject.asObservable();
    }


    sendMessageForSearchStr(message: any) {
        this.searchString.next(message);
    }

    clearMessageForSearchStr() {
        this.searchString.next();
    }

    getMessageForSearchStr(): Observable<any> {
        return this.searchString.asObservable();
    }
}
