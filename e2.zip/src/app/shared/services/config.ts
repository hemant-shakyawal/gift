
export class Config {
    static productData = {
        productDetail : ''
    } 
  
}

