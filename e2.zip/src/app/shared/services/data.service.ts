import {Injectable} from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import {Observable} from 'rxjs';
import {BehaviorSubject} from 'rxjs';
import { Http, Response, URLSearchParams, Headers, RequestOptions, RequestOptionsArgs, ResponseType } from '@angular/http';
import { GetCategoryDetail, CategoryList, Productlist, GetProductDetail, GenerateHash } from '../../model/api.model';
import { UrlConstants } from '../../urls/url-constants';

//  const httpOptions = {
//     headers: new HttpHeaders({ 'Content-Type': 'application/json','authorization':'29HOQ3QTMCF2KS2foCEmNmgowhhUHh2h' })
//  };

@Injectable()
export class DataService {

// headers: HttpHeaders;
// reqOptions: RequestOptions;
// reqArgs: RequestOptionsArgs;
// responseType: ResponseType;

authHeaders: HttpHeaders;    
private messagesource= new BehaviorSubject<string>('');
curentmessage=this.messagesource.asObservable();
private authorsource= new BehaviorSubject<string>('');
authormessage=this.authorsource.asObservable();
    
    constructor( private http: HttpClient) {
       this.authHeaders = new HttpHeaders({'Content-type': 'application/json;charset=UTF-8','Authorization':'$2y$10$QI49JvNHcVJbldi9KMCBeeNRxatK/XVYUNgyL2HsG1HR4RiPyayDq'});
    }

    // Error handling
    handleError(error: any) {
        console.error('server error:', error);
        if (error instanceof Response) {
            let errMessage = '';
            try {
                errMessage = error.json().error;
                console.log(error.headers.toString() + 'Url: ' + error.url);
            } catch (err) {
                errMessage = error.statusText;
            }
            return Observable.throw(errMessage);
        }
        return Observable.throw(error || 'Node.js server error');
    }

    // Extract data and return it
    private extractData(res: Response) {
        const body = res.json();
        return body.data;
    }
    
    private sendFileUploadResponse(res) {
        return res || {};
    }
    
    // ----------- Requests -----------   
        
    getCategoryDetail(Categoryinfo): Observable<GetCategoryDetail> {
        console.log("service calling for getting all categoty");
        return this.http.post<GetCategoryDetail>(UrlConstants.getCategoryDetail, Categoryinfo, {headers: this.authHeaders}); 
            
    }
    CategoryDetail(CategoryDetailinfo): Observable<GetCategoryDetail> {
        console.log("service calling for get category product!");
        return this.http.post<GetCategoryDetail>(UrlConstants.CategoryDetail, CategoryDetailinfo, {headers: this.authHeaders});        
    }

    getProductDetail(ProductDetailinfo):Observable<GetProductDetail>{
        console.log("service calling for get product  Detail!");
        return this.http.post<GetProductDetail>(UrlConstants.ProductDetail, ProductDetailinfo, {headers: this.authHeaders});
    }



    generateHash(ProductDetailinfo):Observable<GenerateHash>{
        console.log("service calling for get product  Detail!");
        return this.http.post<GenerateHash>(UrlConstants.GenerateHash, ProductDetailinfo, {headers: this.authHeaders});
    }

    getSearchDetail(SerarchDetailinfo):Observable<GetProductDetail>{
        console.log("service calling for product serarch  Detail!");
        return this.http.post<GetProductDetail>(UrlConstants.SearchDetail, SerarchDetailinfo, {headers: this.authHeaders}); 
    }
    

    changemessage(message:string){
        this.messagesource.next(message)
    }


// getauthordetail():Observable<AuthDetail>{
//     console.log(" Author service calling");
//     return this.http.get<AuthDetail>('./assets/authors.json'); 

// }

// auhtormessage(amessage:string){
//     this.authorsource.next(amessage)
// }


}
