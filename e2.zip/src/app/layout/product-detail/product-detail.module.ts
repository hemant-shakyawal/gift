import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProductDetailRoutingModule } from './product-detail-routing.module';
import { ProductDetailComponent } from './product-detail.component';
import {FormsModule, ReactiveFormsModule} from '@angular/forms';

@NgModule({
  imports: [
    CommonModule, 
    ProductDetailRoutingModule,
    FormsModule,
    ReactiveFormsModule
  ],
  declarations: [ProductDetailComponent]
})
export class ProductDetailModule {}
