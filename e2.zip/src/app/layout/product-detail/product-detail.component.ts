import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { NotificationService } from '../../shared/services/app-notification.service';
import { GetCategoryDetail, CategoryList, Productlist, GetProductDetail } from '../../model/api.model';
import { DataService } from '../../shared/services/data.service';
import { Constant } from '../../urls/constant';
@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.scss'],
  animations: [routerTransition()]
})
export class ProductDetailComponent implements OnInit {
  loaderStatus = false;
  public navigationSubscription;
  public ProductData: Productlist;
  public productid = {};
  public storeProData = [];
  getcatid: any;
  showData = ''
  getdata: any;
  statuscat;
  public oarr;


  constructor(private dataService: DataService, private notificationservice: NotificationService, private activeroute: ActivatedRoute, public router: Router) {
  
    this.ProductData = <Productlist>new Array();
    this.activeroute.params.subscribe(params => {
      this.productid = params;
    });
    // this.router.events.subscribe((e: any) => {
    //  // console.log('Router event:', e);
    //   this.ngOnInit();
    // });
    this.navigationSubscription = this.router.events.subscribe((e: any) => {
      // If it is a NavigationEnd event re-initalise the component
      if (e instanceof NavigationEnd) {
        this.ngOnInit();
      }
    });
    this.oarr = Constant.optionArr;
  }

  ngOnInit() {
    this.getproductdetail();


  }

  ngOnDestroy() {
    // avoid memory leaks here by cleaning up after ourselves. If we  
    // don't then we will continue to run our initialiseInvites()   
    // method on every navigationEnd event.
    if (this.navigationSubscription) {
      console.log('====>unsubscribe');
      this.navigationSubscription.unsubscribe();
    }
  }

  getproductdetail() {
    this.loaderStatus = true;
    this.dataService.getProductDetail(this.productid).subscribe(result => {
      const prodData = <Productlist>result.data;
      this.ProductData = prodData[0];
      this.loaderStatus = false;
      let len = (this.oarr).length;
      var catstatus = true;
      for (let i = 0; i < len; i++) {
        if (this.ProductData.category_id === this.oarr[i]) {
          catstatus = false;
          break;
        }
      }
      if (catstatus) {
        this.statuscat = true;
      }

    }, err => {
      this.showData = JSON.stringify(err);
      console.log(err);
    });

  }

  clickOnBuyNow(proDetail) {

    let proObject = {
      product_id: '',
      image: '',
      price: '',
      category_id: '',
      name: '',
      description: '',
      meta_description: '',
      meta_keyword: '',
      proQuantity: '',
      proWight: '',
      proQuality: '',
      proMessage: ''
    }

    let productArr = localStorage.getItem('getproduct');
    this.storeProData = [];
    if (productArr) {
      let proStatus = true;
      this.storeProData = JSON.parse(productArr);
      this.storeProData.forEach(element => {
        if (element['product_id'] === this.ProductData.product_id) {
          proStatus = false;
        }
      });
      if (proStatus) {
        proObject.product_id = this.ProductData.product_id;
        proObject.image = this.ProductData.image;
        proObject.price = this.ProductData.price;
        proObject.category_id = this.ProductData.category_id;
        proObject.name = this.ProductData.name;
        proObject.description = '';//this.ProductData.description;
        proObject.meta_description = '';//this.ProductData.meta_description;
        proObject.meta_keyword = this.ProductData.meta_keyword;
        proObject.proQuantity = '1';
        if (this.ProductData.proWight) {
          proObject.proWight = this.ProductData.proWight;
        }
        if (this.ProductData.proQuality) {
          proObject.proQuality = 'Eggless';
        }
        if (this.ProductData.proMessage) {
          proObject.proMessage = this.ProductData.proMessage;
        }
        this.storeProData.push(proObject);
        localStorage.setItem('getproduct', JSON.stringify(this.storeProData));
      }
    } else {
      proObject.product_id = this.ProductData.product_id;
      proObject.image = this.ProductData.image;
      proObject.price = this.ProductData.price;
      proObject.category_id = this.ProductData.category_id;
      proObject.name = this.ProductData.name;
      proObject.description = ''; //this.ProductData.description;
      proObject.meta_description = '';//this.ProductData.meta_description;
      proObject.meta_keyword = this.ProductData.meta_keyword;
      proObject.proQuantity = '1';
      if (this.ProductData.proWight) {
        proObject.proWight = this.ProductData.proWight;
      }
      if (this.ProductData.proQuality) {
        proObject.proQuality = 'Eggless';
      }
      if (this.ProductData.proMessage) {
        proObject.proMessage = this.ProductData.proMessage;
      }
      this.storeProData.push(proObject);
      localStorage.setItem('getproduct', JSON.stringify(this.storeProData));
    }
    let proCount = this.storeProData.length;
    this.notificationservice.sendMessage('' + proCount);
    this.router.navigate(['/view-cart']);
  }

}