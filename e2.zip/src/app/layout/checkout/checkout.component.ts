import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { Productlist,UserDetailForPayment } from '../../model/api.model';
import { DataService } from '../../shared/services/data.service';
import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';
import { Constant } from '../../urls/constant';
import { Router } from '@angular/router';

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.scss'],
  animations: [routerTransition()]
})
export class CheckoutComponent implements OnInit {
  
  public ProductData = <Productlist>new Array();
  public userdetailforpayment;
  public proCount    = 0;
  public hash    = '';
  public txnid    = '';
  public user_id    = '';
  public receiver_id    = '';
  public productName    = '';
  public payeName    = '';
  public payeEmail    = '';
  public payeMobile    = '';
  public totalamount = '0.0';
  public paySuccessUrl = '';


  closeResult: string;

  constructor(private dataService: DataService,private modalService: NgbModal,public router: Router) {
    if(Constant.userdetailforpayment === undefined || Constant.userdetailforpayment === null){
      this.router.navigate(['/view-cart']);
      return;
    }else {
      this.userdetailforpayment = <UserDetailForPayment>Constant.userdetailforpayment;
      console.log(this.userdetailforpayment);
    }    

    this.paySuccessUrl = Constant.paysuccess;

    //new UserDetailForPayment('','','','','sender address','324005','hemant','hemant@gmail.com','9414870720','receiver address','324005','0.0',null);
  }

  ngOnInit() {
    if(this.userdetailforpayment){
      let holdArr = new Array();
      var retrievedData = localStorage.getItem("getproduct");
      holdArr       = JSON.parse(retrievedData);
      this.proCount     = holdArr.length;
      this.ProductData  = <Productlist>holdArr;  
      this.userdetailforpayment.productDetail = this.ProductData;
      this.changeQuantity(holdArr);
    }    
  }

  changeQuantity(holdArrData) {
    let holdArr = holdArrData;
    let holdTotalprice = 0;
    holdArr.forEach(element => {   
      element.proQuantity = element.proQuantity === '' ? 1 : element.proQuantity;
      let price = parseFloat(element.price);
      let proQuantity = parseFloat(element.proQuantity);
      holdTotalprice = holdTotalprice + (price * proQuantity);      
    });
    this.totalamount = parseFloat('' + holdTotalprice).toFixed(2);
    this.userdetailforpayment.totalAmount = this.totalamount;
  }

  generateHash(content){
    this.getCategoryinfo(content);
  }
  
  getCategoryinfo(content) {
    var myJSONObject = {userdetailforpayment: JSON.stringify(this.userdetailforpayment)};
    this.dataService.generateHash(myJSONObject).subscribe(result => {

      this.hash   = result.data.hash;
      this.txnid  = result.data.txnid;
      this.user_id  = result.data.user_id;
      this.receiver_id  = result.data.receiver_id;
      this.productName  = result.data.productinfo;
      this.payeName  = result.data.firstname;
      this.payeEmail  = result.data.email;
      this.payeMobile  = result.data.mobile;
     
      this.modalService.open(content).result.then((result) => {      
        this.closeResult = `Closed with: ${result}`;
      }, (reason) => {
        this.closeResult = `Dismissed ${this.getDismissReason(reason)}`;
      });      
      console.log(this.hash);




    }, err => {
      console.log(err);     
    });
  }  

  private getDismissReason(reason: any): string {
    if (reason === ModalDismissReasons.ESC) {
      return 'by pressing ESC';
    } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
      return 'by clicking on a backdrop';
    } else {
      return  `with: ${reason}`;
    }
  }
}
