import { Component, OnInit } from '@angular/core';
import { Router, NavigationEnd } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { NotificationService } from '../../../shared/services/app-notification.service';
import { Config } from '../../../shared/services/config';
import { AfterViewInit, ViewChild } from '@angular/core';
import { CategoryList, Productlist } from '../../../model/api.model';
import { DataService } from '../../../shared/services/data.service';

@Component({
    selector: 'app-header',
    templateUrl: './header.component.html',
    styleUrls: ['./header.component.scss']
})
export class HeaderComponent implements OnInit {
    public isCollapsed = true;
    pushRightClass: string = 'push-right';
    public productCount = '0';
    public searchtext = '';
    public CategoryData: CategoryList;
    public ProductData: Productlist;
    public filterdarr = [];
    showData = ''
    isIn = false;   // store state
    toggleState() { // click handler
        let bool = this.isIn;
        this.isIn = bool === false ? true : false; 
    }
    constructor(private dataService: DataService, private translate: TranslateService, private router: Router, private notificationservice: NotificationService) {
        let productArr = localStorage.getItem('getproduct');
        if (productArr) {
            const storeProData = JSON.parse(productArr);
            this.productCount = '' + storeProData.length;
        }
    }

      ngOnInit() {
        this.notificationservice.getMessage().subscribe(message => {
            console.log('' + message);
            this.productCount = message
        });
    }

    isToggled(): boolean {
        const dom: Element = document.querySelector('body');
        return dom.classList.contains(this.pushRightClass);
    }

    toggleSidebar() {
        const dom: any = document.querySelector('body');
        dom.classList.toggle(this.pushRightClass);
    }

    clickOnCart() {
        this.router.navigate(['/view-cart']);
    }

    clickOnProcutdetail(pickProdData) {
        this.filterdarr = new Array();
        // console.log(pickProdData);
        this.searchtext = pickProdData.name;
        this.router.navigate(['/product-detail', pickProdData.category_id, pickProdData.product_id]);

    }

    onSearchChange() {

        let searchUrl = this.router.url;
        const urlArr = searchUrl.split('/');
        let  holdurlArr =  urlArr.filter((element) => {
            return element != '' && element != undefined && element != null;
        });

        if(holdurlArr[0] !== 'search'){
                this.router.navigate(['/search']);
        }

        if (this.searchtext != '') {
            this.notificationservice.sendMessageForSearchStr(this.searchtext);
        }

        // this.filterdarr = new Array();
        // if (this.searchtext != '') {
        //     var myJSONObject = {};
        //     myJSONObject['productName'] = this.searchtext;
        //     this.dataService.getSearchDetail(myJSONObject).subscribe(result => {
        //         this.filterdarr = result.data;
        //     }, err => {
        //         this.showData = JSON.stringify(err);
        //         console.log(err);
        //     });
        // }
    }

    /* 
    for the local search
    onSearchChange(search) {
 
         this.filterdarr = new Array();
         // let searchDetail = Config.productData;
         let setionDetail = sessionStorage.getItem("setdetail");
         let holdkey = JSON.parse(setionDetail);
       
         holdkey.forEach(element => {
             element.productDetail.forEach(element => {
                 let productname = '' + element.name;
                 if (productname.includes(this.searchtext)) {
                     this.filterdarr.push(element);
                 }
             });
         });
         console.log(this.filterdarr);
       
 
     }*/


    searchProductByCateName(categoryName) {
        this.isCollapsed = this.isCollapsed ? false : true;
        this.router.navigate(['viewall-product', categoryName]);
    }

    clickhome(){
        this.isCollapsed = this.isCollapsed ? false : true;
        this.router.navigate(['home']);

    }

}
