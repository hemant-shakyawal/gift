import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ViewallProductRoutingModule } from './viewall-product-routing.module';
import { ViewallProductComponent } from './viewall-product.component';
import { InfiniteScrollModule } from 'ngx-infinite-scroll';

@NgModule({
  imports: [
    CommonModule, 
    ViewallProductRoutingModule,
    InfiniteScrollModule
  ],
  declarations: [ViewallProductComponent]
})
export class ViewallProductModule { }
