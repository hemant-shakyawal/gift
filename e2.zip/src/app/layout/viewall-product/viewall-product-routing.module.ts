import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ViewallProductComponent } from './viewall-product.component';

const routes: Routes = [
    {
        path: '', component: ViewallProductComponent
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class ViewallProductRoutingModule {
}
