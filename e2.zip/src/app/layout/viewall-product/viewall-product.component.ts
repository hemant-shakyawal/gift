import { Component, OnInit, OnDestroy } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { DataService } from '../../shared/services/data.service';
import { NotificationService } from '../../shared/services/app-notification.service';
import { routerTransition } from '../../router.animations';
import { GetCategoryDetail, CategoryList, Productlist } from '../../model/api.model';

@Component({
  selector: 'app-viewall-product',
  templateUrl: './viewall-product.component.html',
  styleUrls: ['./viewall-product.component.scss'],
  animations: [routerTransition()]
})

export class ViewallProductComponent implements OnInit {
  loaderStatus = false;
  public CategoryData: CategoryList;
  public ProductData: Productlist;
  public ProductDataCount = 0;
  public queryParameter = {};
  public perameterJson = {};
  getcatid: any;
  showData = ''
  prolenth: any;
  loadMore: any;

  public pageData = 10;
  public throttle = 10;
  public scrollDistance = 1;
  public scrollUpDistance = 2;
  public holdProductData = [];
  public navigationSubscription;

  constructor(private activeroute: ActivatedRoute, public router: Router, private dataService: DataService, private notificationservice: NotificationService, ) {
    this.CategoryData = new CategoryList();
    this.ProductData = <Productlist>new Array();

    this.activeroute.params.subscribe(params => {
      this.queryParameter = params;
    });

    this.navigationSubscription = this.router.events.subscribe((e: any) => {
      // If it is a NavigationEnd event re-initalise the component
      if (e instanceof NavigationEnd) {
        this.CategoryData = new CategoryList();
        this.ProductData = <Productlist>new Array();
        this.ngOnInit();
      }
    });

    // this.router.events.subscribe((e: any) => {     
    //   this.counter++;
    //   console.log(e);     
    // });
  }

  ngOnDestroy() {
    // avoid memory leaks here by cleaning up after ourselves. If we  
    // don't then we will continue to run our initialiseInvites()   
    // method on every navigationEnd event.
    if (this.navigationSubscription) {
      console.log('====>unsubscribe');  
       this.navigationSubscription.unsubscribe();
    }
  }

  ngOnInit() {
    this.loaderStatus = true;
  //  console.log(this.queryParameter);
    let parameter = this.queryParameter["categoryId"];
    switch (parameter) {
      case 'Valentine-Cakes':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Valentine Cakes';
        break;

      case 'Cartoon-cakes':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Cartoon cakes';
        break;

      case '1-kg-cakes':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = '1 kg cakes';
        break;

      case 'Half-kg-Cakes':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Half kg Cakes';
        break;

      case 'Online-Cake-Home-Delivery-Shop':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Online Cake Home Delivery Shop';
        break;


      case 'Combo-Flowers-&-Cakes-Gifts':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Combo Flowers & Cakes Gifts';
        break;

      case 'Basket-Arrangement':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Basket Arrangement';
        break;

      case 'Flowers-bunch':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Flowers bunch';
        break;

      case 'Glass-Vase-Arrangements':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Glass Vase Arrangements';
        break;

      case 'Premium-Arrangements':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Premium Arrangements';
        break;

      case 'Anniversaries-cakes':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Anniversaries cakes';
        break;

      case 'Gift-under-500':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Gift under 500';
        break;

      case 'Divinity':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Divinity';
        break;

      case 'Flowers-in-a-box':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Flowers in a box';
        break;

      case 'Food-Gift-Basket':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Food Gift Basket';
        break;

      case 'Birthday':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Birthday';
        break;

      case 'For-Kids':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'For Kids';
        break;

      case 'Gift-for-her':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Gift for her';
        break;

      case 'Home-&-Garden':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Home & Garden';
        break;

      case 'Midnight-Products':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Midnight Products';
        break;

      case 'Personalized-Gifts':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Personalized Gifts';
        break;

      case 'Congratulations':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Congratulations';
        break;

      case 'Lucky-Bamboo':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Lucky Bamboo';
        break;

      case 'Get-Well-Soon':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Get Well Soon';
        break;

      case 'I-am-Sorry':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'I am Sorry';
        break;

      case 'Chocolates':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Chocolates';
        break;

      case 'Gifts-for-Top-Metros':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Gifts for Top Metros';
        break;

      case 'Soft-Toys':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Soft Toys';
        break;

      case 'Love':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Love';
        break;

      case 'Fathers-day':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Fathers day';
        break;

      case 'Eggless-cake':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Eggless cake';
        break;

      case 'Five-Star-Cake':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Five Star Cake';
        break;

      case 'Regular-Cake':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Regular Cake';
        break;

      case 'Special-Cake':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Special Cake';
        break;

      case 'Chocolates':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Chocolates';
        break;

      case 'Pineapple-cakes':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Pineapple cakes';
        break;


      case 'fruit-cakes':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'fruit cakes';
        break;

      case 'Chocolate-cakes':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Chocolate cakes';
        break;


      case 'Strawberry-cakes':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Strawberry cakes';
        break;


      case 'Plants':
        this.perameterJson['categoryId'] = '';
        this.perameterJson['categoryName'] = 'Plants';
        break;

      default:
        this.perameterJson['categoryId'] = parameter;
        this.perameterJson['categoryName'] = '';
        break;
    }    
    // console.log('=====================>');
    // console.log(this.perameterJson);
    this.getCategotyData();
  }

  getCategotyData() {   
    this.dataService.CategoryDetail(this.perameterJson).subscribe(result => {
      if (result.data.length > 0) {
        const catData = <CategoryList>result.data;
        this.CategoryData = catData[0];
        //this.ProductData = <Productlist>this.CategoryData.productDetail;
        this.holdProductData = this.CategoryData.productDetail;
        this.ProductDataCount = this.CategoryData.productDetail.length
        this.fillData()
      }else{
        this.loaderStatus = false;
      }
    }, err => {
      this.loaderStatus = false;
      this.showData = JSON.stringify(err);
      console.log(err);
    });
  }

  clickOnProcutdetail(pickProdData) {
    // console.log(pickProdData);  
    this.router.navigate(['/product-detail', pickProdData.category_id, pickProdData.product_id]); 
  }

  onScroll() {
    this.pageData += 10;
    this.fillData();
  }

  fillData() {
    var holdArr = [];
    for (var i = 0; i < this.pageData; i++) {
      if (i <= this.holdProductData.length - 1) {
        holdArr.push(this.holdProductData[i]);
      }
    }
    this.ProductData = <Productlist>holdArr;
   // console.log(holdArr.length);
    this.loaderStatus = false;
  }

}
