import { Component, OnInit } from '@angular/core';
import { routerTransition } from '../../router.animations';
import { Router, ActivatedRoute } from '@angular/router';
import { GetCategoryDetail, CategoryList, Productlist } from '../../model/api.model';
import { DataService } from '../../shared/services/data.service';
import { NotificationService } from '../../shared/services/app-notification.service';
import { Config } from '../../shared/services/config';


@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss'],
  animations: [routerTransition()]
})

export class HomeComponent implements OnInit {

 // productcount = [1, 2, 3, 4];
  cat_name: string = "";
  showData = ''
  loaderStatus = false;

  public CategoryData: CategoryList;
  public ProductData: Productlist;
  public proCount = '0';
  public productid = {};
  public storeProData = [];
  public pageData          = 10;
  public throttle          = 10;
  public scrollDistance    = 1;
  public scrollUpDistance  = 2; 
  public holdCategogyData  = [];

  constructor(private activeroute: ActivatedRoute, public router: Router, private dataService: DataService,private notificationservice: NotificationService) {
  }

  ngOnInit() {
    this.CategoryData = <CategoryList>new Array();
    this.ProductData = <Productlist>new Array();
    this.getCategoryinfo(); 
  }

  clickOnViewall(pickedCateData) {  
      this.router.navigate(['viewall-product', pickedCateData.category_id]); 
    // this.router.navigate(['/viewall-product'], {queryParams: {'productData': JSON.stringify(pickedCateData)}, skipLocationChange: true});
  }

  clickOnProcutdetail(pickProdData) {
  this.router.navigate(['/product-detail',pickProdData.category_id,pickProdData.product_id]);
  }

  getCategoryinfo() {
    this.loaderStatus = true;
    var myJSONObject = {};
    this.dataService.getCategoryDetail(myJSONObject).subscribe(result => {       
      Config.productData.productDetail = JSON.stringify(result.data); 
      this.holdCategogyData = result.data;
      this.fillCategoryData();
      // this.CategoryData = <CategoryList>result.data;
      // console.log(this.CategoryData);
      //console.log("Final response" + JSON.stringify(result));
    }, err => {
      this.loaderStatus = false;
      this.showData = JSON.stringify(err);
      console.log(err);
      //  console.log(c);
    });
  }

  clickbuy(pickbuydetail) {     
    this.loaderStatus = true;

    let proObject = {
      product_id:'',
      image:'',
      price:'',
      category_id:'',
      name:'',
      description:'',
      meta_description:'',
      meta_keyword:'',
      proQuantity:''
   }
   
   let productArr = localStorage.getItem('getproduct');
   this.storeProData = [];
     if(productArr){
         let proStatus = true;
         this.storeProData = JSON.parse(productArr);
         this.storeProData.forEach(element => { 
           if(element['product_id'] ===  pickbuydetail.product_id){
             proStatus = false;
           }        
         });      
         if(proStatus){
           proObject.product_id = pickbuydetail.product_id;
           proObject.image = pickbuydetail.image;
           proObject.price = pickbuydetail.price;
           proObject.category_id = pickbuydetail.category_id;
           proObject.name = pickbuydetail.name;
           proObject.description = '';//pickbuydetail.description;
           proObject.meta_description = '';//pickbuydetail.meta_description;
           proObject.meta_keyword = pickbuydetail.meta_keyword;
           proObject.proQuantity = '1';
           this.storeProData.push(proObject);
           localStorage.setItem('getproduct', JSON.stringify(this.storeProData));
         }
     } else { 
       proObject.product_id = pickbuydetail.product_id;
       proObject.image = pickbuydetail.image;
       proObject.price = pickbuydetail.price;
       proObject.category_id = pickbuydetail.category_id;
       proObject.name = pickbuydetail.name;
       proObject.description = ''; //pickbuydetail.description;
       proObject.meta_description = ''; //pickbuydetail.meta_description;
       proObject.meta_keyword = pickbuydetail.meta_keyword;
       proObject.proQuantity = '1';
       this.storeProData.push(proObject);
       localStorage.setItem('getproduct', JSON.stringify(this.storeProData));
     }
     let proCount = this.storeProData.length;
     this.notificationservice.sendMessage(''+proCount);
     this.loaderStatus = false;
     this.router.navigate(['/view-cart']);
   }

   onScroll(){
     console.log('here i am!!!!!!!!!!!!!!!!!!!!!');
     this.pageData += 10;
     this.fillCategoryData();
   }

   fillCategoryData() {
     var holdArr = [];
      for (var i=0;i<this.pageData;i++){
        if(i<=this.holdCategogyData.length-1){
          holdArr.push(this.holdCategogyData[i]);
        }
      }
      this.CategoryData = <CategoryList>holdArr;
      console.log(holdArr.length);
      this.loaderStatus = false;
   }

}
