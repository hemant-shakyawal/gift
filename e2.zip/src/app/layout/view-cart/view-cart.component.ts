import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { routerTransition } from '../../router.animations';
import { AuthService } from 'angularx-social-login';
import { SocialUser } from 'angularx-social-login';
import { GoogleLoginProvider, FacebookLoginProvider, } from 'angularx-social-login';
import { Productlist, UserDetailForPayment } from '../../model/api.model';
import { DataService } from '../../shared/services/data.service';
import { FormControl, FormGroup, Validators, FormBuilder } from "@angular/forms";
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { Constant } from '../../urls/constant';
import { NotificationService } from '../../shared/services/app-notification.service';


@Component({
  selector: 'app-view-cart',
  templateUrl: './view-cart.component.html',
  styleUrls: ['./view-cart.component.scss'],
  animations: [routerTransition()]
})

export class ViewCartComponent implements OnInit {
  user: SocialUser;
  public ProductData = <Productlist>new Array();
  public userdetailforpayment;
  public proCount = 0;
  public ProductDataCount = 0;
  public totalamount = '0.0';
  public hash = '';
  public txnid = '';
  public statusmessage = '';
  formGroup: FormGroup;
  submitted = false;

  textValue: number = 1;
  constructor(private authService: AuthService, private activeroute: ActivatedRoute, public router: Router, private dataService: DataService, private formBuilder: FormBuilder, private modalService: NgbModal, private notificationservice: NotificationService) {
    this.userdetailforpayment = new UserDetailForPayment('', '', '', '', '', '', '', '', '', '', '', '0.0', null);
    if (!localStorage.getItem("getproduct")) {
      this.router.navigate(['/home']);
    }
  }

  ngOnInit() {

    var that = this;
    this.authService.authState.subscribe((socialDetail) => {

      if (socialDetail) {

        //console.log(socialDetail);
        that.user = socialDetail;

        that.userdetailforpayment.socialId = socialDetail['id'];
        that.userdetailforpayment.s_name = socialDetail['name'];
        that.userdetailforpayment.s_email = socialDetail['email'];
        that.userdetailforpayment.socialId = socialDetail['id'];

        this.formGroup = this.formBuilder.group({
          s_name: new FormControl(socialDetail['name'], Validators.required),
          s_email: new FormControl(socialDetail['email'], [
            Validators.required,
            Validators.pattern(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)
          ]),

          s_mobile: new FormControl('', [
            Validators.required,
            Validators.minLength(10),
            Validators.maxLength(10),
            Validators.pattern(/^((\\+91-?)|0)?[0-9]{10}$/)
            //  Validators.pattern(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)  
          ]),
          s_address: new FormControl('', [
            Validators.required
          ]),
          s_pin: new FormControl('', [
            Validators.required
          ]),

          r_name: new FormControl('', Validators.required),
          r_email: new FormControl('', [
            Validators.required,
            Validators.pattern(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)
          ]),

          r_mobile: new FormControl('', [
            Validators.required,
            Validators.minLength(10),
            Validators.maxLength(10),
            Validators.pattern(/^((\\+91-?)|0)?[0-9]{10}$/)
            //  Validators.pattern(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)  
          ]),
          r_address: new FormControl('', [
            Validators.required
          ]),
          r_pin: new FormControl('', [
            Validators.required
          ])
        });

        setTimeout(() => {    //<<<---    using ()=> syntax
          this.authService.signOut();
        }, 2000);
      }
      // if (this.user) {
      //   this.userdetailforpayment.s_name = this.user['firstName'] + ' ' + this.user['lastName'];
      //   this.userdetailforpayment.s_email = this.user['email'];
      //   this.userdetailforpayment.socialId = this.user['id'];
      //   this.ngOnInit();
      // }
    });

    this.formGroup = this.formBuilder.group({
      s_name: new FormControl(this.userdetailforpayment.s_name, Validators.required),
      s_email: new FormControl(this.userdetailforpayment.s_email, [
        Validators.required,
        Validators.pattern(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)
      ]),

      s_mobile: new FormControl('', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern(/^((\\+91-?)|0)?[0-9]{10}$/)
        //  Validators.pattern(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)  
      ]),
      s_address: new FormControl('', [
        Validators.required
      ]),
      s_pin: new FormControl('', [
        Validators.required
      ]),

      r_name: new FormControl('', Validators.required),
      r_email: new FormControl('', [
        Validators.required,
        Validators.pattern(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)
      ]),

      r_mobile: new FormControl('', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
        Validators.pattern(/^((\\+91-?)|0)?[0-9]{10}$/)
        //  Validators.pattern(/^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/)  
      ]),
      r_address: new FormControl('', [
        Validators.required
      ]),
      r_pin: new FormControl('', [
        Validators.required
      ])
    });

    let holdArr = new Array();
    var retrievedData = localStorage.getItem("getproduct");
    holdArr = JSON.parse(retrievedData);
    this.proCount = holdArr.length;
    this.ProductData = <Productlist>holdArr;

    if (this.proCount === 0) {
      this.router.navigate(['/home']);
    }
    // console.log(this.ProductData);

    // this.authService.authState.subscribe((user) => {
    //   console.log(user);
    //   this.user = user;
    // });
    this.changeQuantity(holdArr);
  }

  changeQuantity(holdArrData) {

    let holdArr = holdArrData;
    let holdTotalprice = 0;
    holdArr.forEach(element => {
      // if(element.proQuantity != ''){
      element.proQuantity = element.proQuantity === '' ? 1 : element.proQuantity;
      let price = parseFloat(element.price);
      let proQuantity = parseFloat(element.proQuantity);
      holdTotalprice = holdTotalprice + (price * proQuantity);
      // }     
    });
    this.totalamount = parseFloat('' + holdTotalprice).toFixed(2)
    this.ProductData = <Productlist>holdArrData;
    localStorage.setItem('getproduct', JSON.stringify(this.ProductData));
  }


  /*gettotal(){
  
  console.log(this.ProductData) ;
  // for (let i = 0; i < this.ProductData.length; i++) {
  //   const element = array[index];
    
  // } 
  let total = 0;
      for (var i = 0; i < this.ProductData; i++) {
          if (this.ProductData[i].amount) {
              total += this.ProductData[i].amount;
              this.totalamount = total;
          }
      }
      return total;
  }*/

  signInWithGoogle(): void {
    this.authService.signIn(GoogleLoginProvider.PROVIDER_ID);
  }

  signInWithFB(): void {
    this.authService.signIn(FacebookLoginProvider.PROVIDER_ID);
  }

  // signInWithLinkedIn(): void {
  //   this.authService.signIn(LinkedInLoginProvider.PROVIDER_ID);
  // }

  signOut(): void {
    this.authService.signOut();
  }

  // clickOnCheckout() {

  //   console.log(this.formGroup);
  //   //this.router.navigate(['/checkout']);
  //   // this.getCategoryinfo();
  // }


  // convenience getter for easy access to form fields
  get f() { return this.formGroup.controls; }

  clickOnCheckout(modelContent) {

    if (this.userdetailforpayment.socialId === '' || this.userdetailforpayment.socialId === undefined) {
      this.statusmessage = 'please login first with facebook or google';
      this.modalService.open(modelContent, { size: 'sm' });
      return
    }

    this.submitted = true;
    // stop here if form is invalid
    if (this.formGroup.invalid) {
      return;
    }

    if (this.formGroup.valid) {
      let formValues = this.formGroup.value;
      this.userdetailforpayment.s_name = formValues.s_name;
      this.userdetailforpayment.s_email = formValues.s_email;
      this.userdetailforpayment.s_mobile = formValues.s_mobile;
      this.userdetailforpayment.s_address = formValues.s_address;
      this.userdetailforpayment.s_pin = formValues.s_pin;

      this.userdetailforpayment.r_name = formValues.r_name;
      this.userdetailforpayment.r_email = formValues.r_email;
      this.userdetailforpayment.r_mobile = formValues.r_mobile;
      this.userdetailforpayment.r_address = formValues.r_address;
      this.userdetailforpayment.r_pin = formValues.r_pin;
      this.userdetailforpayment.totalAmount = this.totalamount;
      Constant.userdetailforpayment = this.userdetailforpayment;
      this.router.navigate(['/checkout']);
      //console.log(this.userdetailforpayment);
    }
  }

  // getCategoryinfo() {
  //   var myJSONObject = { amount: "500", productinfo: "cake", firstname: "hemraj", email: "hemrajshaqawal@gmail.com" }
  //   this.dataService.generateHash(myJSONObject).subscribe(result => {
  //     this.hash = result.data.hash
  //     this.txnid = result.data.txnid
  //     console.log(this.hash);
  //     console.log(this.txnid);
  //   }, err => {
  //     console.log(err);
  //   });
  // }

  deleteProduct(peoItemIndex) {
    console.log(peoItemIndex);
    var retrievedData = localStorage.getItem("getproduct");
    let holdArr = JSON.parse(retrievedData);
    holdArr.splice(peoItemIndex, 1);
    this.ProductData = <Productlist>holdArr;
    let proCount = holdArr.length;
    this.notificationservice.sendMessage('' + proCount);

    if (proCount === 0) {
      this.router.navigate(['/home']);
    }

    localStorage.setItem("getproduct", JSON.stringify(holdArr));
    this.changeQuantity(holdArr);
  }

  loadUserDetail(userDetail: SocialUser) {
    console.log('=======================> load userDetail');
    console.log(userDetail.firstName);
  }


}
