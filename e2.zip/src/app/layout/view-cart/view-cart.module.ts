import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ViewCartRoutingModule } from './view-cart-routing.module';
import { ViewCartComponent } from './view-cart.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  imports: [
    CommonModule, 
    ViewCartRoutingModule,
    FormsModule,
    ReactiveFormsModule ,
    NgbModule
  ],
  declarations: [ViewCartComponent]
})
export class  ViewCartModule { }
