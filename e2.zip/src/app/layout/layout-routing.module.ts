import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LayoutComponent } from './layout.component';

const routes: Routes = [
    {
        path: '',
        component: LayoutComponent,
        children: [
            { path: '', redirectTo: 'home' },
            { path: 'home', loadChildren: './home/home.module#HomeModule' },
            { path: 'viewall-product/:categoryId', loadChildren: './viewall-product/viewall-product.module#ViewallProductModule' },
            { path: 'product-detail/:categoryId/:productId', loadChildren: './product-detail/product-detail.module#ProductDetailModule' },
            { path: 'view-cart', loadChildren: './view-cart/view-cart.module#ViewCartModule' },
           { path: 'checkout', loadChildren: './checkout/checkout.module#CheckoutModule' },
           { path: 'thanks/:status', loadChildren: './thanks/thanks.module#ThanksModule' },
           { path: 'search', loadChildren: './search/search.module#SearchModule' },
                   ],
        runGuardsAndResolvers: 'always',
    }
];


@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule],   
})


export class LayoutRoutingModule {}
