import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { NotificationService } from '../../shared/services/app-notification.service';

@Component({
  selector: 'app-thanks',
  templateUrl: './thanks.component.html',
  styleUrls: ['./thanks.component.scss']
})
export class ThanksComponent implements OnInit {

  public paymentStatus;
  public msg;
  constructor(public router: Router,private notificationservice: NotificationService) { }

  ngOnInit() {
  //  console.log(this.router.url); 
    let URL = this.router.url.split('/');
    if(URL.length > 0) {
      this.paymentStatus = URL[URL.length-1];
      if(URL[URL.length-1] == 'success'){
        this.msg = 'Your submition is received and we will contact you soon.';
        this.notificationservice.sendMessage('0');
        localStorage.removeItem('getproduct');
      }else{
        this.msg = 'There is something went wrong while doing payment.Please try Again';
      }
    }else{
      this.router.navigate(['/home']);
    }   
  }

  clickhome(){
  
    this.router.navigate(['/home']);
  }

}
