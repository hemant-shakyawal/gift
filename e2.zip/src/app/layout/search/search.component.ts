import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { DataService } from '../../shared/services/data.service';
import { NotificationService } from '../../shared/services/app-notification.service';
import { routerTransition } from '../../router.animations';
import { GetCategoryDetail, CategoryList, Productlist } from '../../model/api.model';



@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.scss'],
  animations: [routerTransition()]

})
export class SearchComponent implements OnInit {
  loaderStatus = false;
  public pageData = 10;
  public throttle = 10;
  public scrollDistance = 1;
  public scrollUpDistance = 2;
  public holdProductData = [];
  public navigationSubscription;
  // public ProductData:any;


  public productCount = '0';
  public searchtext = '';
  public CategoryData: CategoryList;
  public ProductData: Productlist;
  public filterdarr = [];
  public storeProData = [];
  
  constructor(private activeroute: ActivatedRoute, public router: Router, private dataService: DataService, private notificationservice: NotificationService) { }

  ngOnInit() {
    this.notificationservice.getMessageForSearchStr().subscribe(message => {
      this.searchtext = message
      this.onSearchChange();
    });
  }

  onSearchChange() {
    this.pageData = 10;
    this.filterdarr = new Array();
    if (this.searchtext != '') {
      var myJSONObject = {};
      myJSONObject['productName'] = this.searchtext;
      this.dataService.getSearchDetail(myJSONObject).subscribe(result => {
        this.filterdarr = result.data;
        if (this.filterdarr.length > 0) {
          this.ProductData = <Productlist>this.filterdarr;
        }
      }, err => {
        // this.showData = JSON.stringify(err);
        console.log(err);
      });
    }
  }

  onScroll() {
    console.log('here i am!!!!!!!!!!!!!!!!!!!!!');
    this.pageData += 10;
    this.fillCategoryData();
  }

  fillCategoryData() {
    var holdArr = [];
    for (var i = 0; i < this.pageData; i++) {
      if (i <= this.filterdarr.length - 1) {
        holdArr.push(this.filterdarr[i]);
      }
    }
    this.ProductData = <Productlist>holdArr;
  }

  clickOnProcutdetail(pickProdData) {
    this.router.navigate(['/product-detail', pickProdData.category_id, pickProdData.product_id]);
  }

  clickbuy(pickbuydetail) {
    this.loaderStatus = true;

    let proObject = {
      product_id: '',
      image: '',
      price: '',
      category_id: '',
      name: '',
      description: '',
      meta_description: '',
      meta_keyword: '',
      proQuantity: ''
    }

    let productArr = localStorage.getItem('getproduct');
    this.storeProData = [];
    if (productArr) {
      let proStatus = true;
      this.storeProData = JSON.parse(productArr);
      this.storeProData.forEach(element => {
        if (element['product_id'] === pickbuydetail.product_id) {
          proStatus = false;
        }
      });
      if (proStatus) {
        proObject.product_id = pickbuydetail.product_id;
        proObject.image = pickbuydetail.image;
        proObject.price = pickbuydetail.price;
        proObject.category_id = pickbuydetail.category_id;
        proObject.name = pickbuydetail.name;
        proObject.description = '';//pickbuydetail.description;
        proObject.meta_description = '';//pickbuydetail.meta_description;
        proObject.meta_keyword = pickbuydetail.meta_keyword;
        proObject.proQuantity = '1';
        this.storeProData.push(proObject);
        localStorage.setItem('getproduct', JSON.stringify(this.storeProData));
      }
    } else {
      proObject.product_id = pickbuydetail.product_id;
      proObject.image = pickbuydetail.image;
      proObject.price = pickbuydetail.price;
      proObject.category_id = pickbuydetail.category_id;
      proObject.name = pickbuydetail.name;
      proObject.description = ''; //pickbuydetail.description;
      proObject.meta_description = ''; //pickbuydetail.meta_description;
      proObject.meta_keyword = pickbuydetail.meta_keyword;
      proObject.proQuantity = '1';
      this.storeProData.push(proObject);
      localStorage.setItem('getproduct', JSON.stringify(this.storeProData));
    }
    let proCount = this.storeProData.length;
    this.notificationservice.sendMessage('' + proCount);
    this.loaderStatus = false;
    this.router.navigate(['/view-cart']);
  }
}
