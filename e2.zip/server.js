const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const http = require('http');
const app = express();
//var Parse = require('parse/node');

// API file for interacting with MongoDB
const api = require('./server/routes/api');

/*const payment = require('./server/routes/payment');
const auth = require('./server/routes/auth');
const modify = require('./server/routes/modify');
const config = require('./server/routes/config');*/

// Parsers
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: false }));

// Angular DIST output folder
app.use(express.static(path.join(__dirname, 'dist')));
app.use('/uploads', express.static(__dirname + '/uploads'));

// Allow access control 
app.use(function(req, res, next) {
    console.log('Allowed access control');
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type, authorization');
    next();
});

// API location
app.use('/api', api);
// app.use('/api/payment', payment);
// app.use('/api/auth', auth);
// app.use('/api/modify', modify);

// Send all other requests to the Angular app
app.get('*', (req, res) => {
    //res.sendFile(path.join(__dirname, 'dist/index.html'));
    res.status(404);
});

//Set Port
const port = process.env.PORT || '9095';
app.set('port', port);

const server = http.createServer(app);

server.listen(port, () => console.log(`Running on localhost:${port}`));